#!/usr/bin/python

# Copyright Greg Detre (2007), released under the GPL.

"""
This is intended for parsing free recall data, recorded
under noisy conditions (like fMRI). In this case, you have a
wordlist of may a few tens or hundreds of words, and your
job is to tell which one the subject is saying each
time. They could come in any order.

This program is not trying to do speech recognition or
anything fancy like that. It's simply intended as a handy
tool for the human doing the parsing. Put simply, you feed
it a wordlist and what you think you hear, and it will
return words (from the wordlist) that might be matches. It's
then up to the human to decide which works best.

This uses the Levenshtein edit distance as applied to the
phonetic distances in the CMU Pronouncing Dictionary.

Usage:
python free_rhycall.py -w wordlist.txt -d cmudict.0.6 wheel

would find possibly phonetic matches for 'wheel', drawn from
within the wordlist 'wordlist.txt', using the CMU
Pronouncing Dictionary in cmudict.0.6 to determine which
words are similar. See the USAGE file for more details.

Alternatively, you can just use it as a library, by calling
the phoncomp() function.

Limitations, issues and future plans:

- the Levenshtein edit distance method this uses doesn't
  take into account the fact that some phonemes are more
  similar to each other than others. It treats all
  replacements as equally costly.

- this reads through the dictionary_file multiple times. It
  might be better to create a hash-table or something, or at
  least provide an interactive mode where it doesn't keep
  reading in and recomputing the same stuff for the same
  wordpools.

- the CMU Pronouncing Dictionary allows some words to have
  multiple pronounciations. I'm not sure what will happen if
  there are multiple representations for your target
  word. It might just pick the first one.

- for some reason, if you set the Levenshtein distance
  threshold to 1, it never finds a match.

- if you want to use it as a library, you'll probably want
  to change the sys.exit lines to exceptions.

- I haven't quite figured out how 'verbose' should
  work. There needs to be a way to turn off the warnings,
  e.g. 'this word is not in the dictionary', for use as a
  library. However, the user should see those by default,
  yet I don't want verbose to be True by default.

- Does it return what's needed in order to use it as a
  library (e.g. within pyparse)?

- It seems as though you want the Levenshtein distance to
  take into account the length of the word. 7 edits on a
  short word gives you almost any other short word, yet 7
  edits on a long word may not get you that many matches.

- If you feed in multiple words, it should prefer
  suggestions that lie somewhere in the middle of your
  guesses. So if you feed in 'puppy' and 'patty' as guesses,
  it should weight 'putty' over 'potty', since 'putty' is
  close to both 'puppy' and 'patty'.

- It should fall back on Soundex (or something akin) for
  words that it doesn't have in its phonetic dictionary.

- It would be nice to able to weight consonants or vowels
  more heavily.

- It would be cool to have a web interface. Then you wouldn't
  need to mess around with installing the Levenshtein stuff
  locally.

"""

import os, sys, string
import pdb

# this does all the heavy lifting in terms of the
# Levenshtein edit distance comparisons. see README for more
# info on getting this library
import Levenshtein

import getopt


# it seemed reasonable to have this as a global variable,
# since it could be relevant in any of the functions, and i
# didn't want to have to keep passing it around, just in
# case
verbose = False



############################################################
def find_matches(targword, targphon, wordlist, phonlist, dist_thresh):

    """
    Find all the matches for a single target word. Return as
    a set.
    """

    matches = set()

    for word,phon in zip(wordlist,phonlist):
        
        if Levenshtein.distance(targphon, phon) < dist_thresh:
            matches.add(word)

    return matches


    
############################################################
def read_dictionary_file(dictionary_file, wordlist_file):

    """
    Read in the CMU Pronouncing Dictionary file
    (e.g. cmudict.0.6). Only read in words in the WORDLIST file.

    Returns a list of words, and a list of their phonetic
    representations (as strings).
    """

    foundwords = []
    foundphons = []

    if len(wordlist_file):
        # the user fed us a foundwords file that we're going
        # to use to restrict which words we care about
        allowed_words = open(wordlist_file,'r').readlines()
        # get rid of blank space, e.g. carriage returns.
        # also, make all the allowed_words upper case,
        # because that's how they're stored in the
        # dictionary
        allowed_words = [x.strip().upper() for x in allowed_words]
        # if there were any empty lines in the wordlist,
        # they'll show up now as empty strings
        if '' in allowed_words:
            allowed_words.remove('')
        
        # so only read in those words from the dictionary file
        dictlines = []
        for line in open(dictionary_file,'r').readlines():

            if line[0:2] == '##':
                # this is a comment line
                continue
            
            # each dictionary line contains the word,
            # followed by two spaces, followed by its
            # phonetic representation. we're checking the
            # word (before the two spaces) against our list
            # of allowed words
            if line.split('  ')[0] in allowed_words:
                dictlines.append(line)

    else:
        # no foundwords file, i.e. consider any potential
        # matches from the whole dictionary
        allowed_words = []
        dictlines = open(dictionary_file,'r').readlines()

    # go through each dictionary line and apportion its word
    # component (prior to the two spaces) to the FOUNDWORDS
    # and its phonetic component to the FOUNDPHONS
    for line in dictlines:

        if line[0:2] == '##':
            # comment line
            continue
        
        if '  ' in line:
            word = line.split('  ')[0]
            phon = line.split('  ')[1]
            foundwords.append(word.strip())
            foundphons.append(phon.strip())
        else:
            continue

    # just check that all the words in the allowed_words
    # wordlist were found in the dictionary
    #
    # only bother if the user fed in an allowed_words
    # wordlist in the first place, and if we're in verbose mode
    if allowed_words and verbose:
        notfoundwords = set(allowed_words).difference(foundwords)
        if len(notfoundwords)==1:
            print '%s from your wordlist was not in the dictionary.' \
                  % string.join(['"%s"' % x for x in notfoundwords], ' and ')
        elif len(notfoundwords)>1:
            print '%s from your wordlist were not in the dictionary.' \
                  % string.join(['"%s"' % x for x in notfoundwords], ' and ')

    return foundwords, foundphons
    


############################################################
def phon_from_word(targword, dictionary_file):

    """
    Look up a single (target) word's phonetic representation
    from the dictionary file.
    """

    targphon = ''

    # get rid of white space (e.g. carriage returns), and
    # make upper case to match the dictionary words
    targword = targword.strip().upper()

    for line in open(dictionary_file,'r').readlines():
        if line[0:2] == '##':
            # comment line
            continue

        if targword == line.split('  ')[0]:
            targphon = line.split('  ')[1]
            break

    if targphon == '':
        print 'I\'m afraid that the phonetic representation for %s isn\'t in your dictionary.' % targword
        sys.exit(2)

    return targphon

    
############################################################
def begin_search(targets, dictionary_file, wordlist_file, dist_thresh):

    """
    Goes through the DICTIONARY file, looking for nearby
    phonetic matches to the TARGETS words. If WORDLIST is
    non-empty, then it will restrict the matches to the list
    of words in the WORDLIST file.
    """

    if not isinstance(targets,list):
        raise 'TARGETS must be a list of strings'

    if len(targets)<1:
        raise 'There must be at least one target word to try and match.'

    wordlist, phonlist = read_dictionary_file(dictionary_file, wordlist_file)

    # print '[wordlist phonlist]:'
    # print zip(wordlist,phonlist)
    # return

    # this is going to contain the set of possible
    # matches. if there are multiple targets, it will
    # eventually contain anything that matched any of the
    # targets (excluding duplicates)
    matches = set()
    for targword in targets:

        # do a little error-checking
        if not isinstance(targword,str):
            raise 'Target word must be a string'

        # it's a bit inefficient to go all the way back
        # through the dictionary file multiple times, when
        # we've already been through it once, but it's
        # simpler for now
        targphon = phon_from_word(targword, dictionary_file)

        # now, our set of matches includes any matches we
        # had before, plus any matches we just found
        matches = matches.union(
            find_matches(targword, targphon, wordlist, phonlist, dist_thresh) )

    # list of words in the wordlist that didn't match
    nonmatches = set(wordlist).difference(matches)

    return matches, nonmatches


    
############################################################
def usage():
    """
    If the user didn't feed in the arguments correctly,
    here's where we school them.
    """

    # if we're in the same directory as the instructions
    # file, spit that out, because it has all the details
    if os.path.exists('USAGE'):
        print open('USAGE','r').read()

    # oh well. can't find the usage file. just barf at the
    # user
    else:
        print 'You didn''t call this correctly. See the free_rhycall USAGE file for more instructions.'



############################################################
def main(argv):
    """
    Parses the command-line arguments. Based on argecho.py:

    http://www.faqs.org/docs/diveintopython/kgp_commandline.html
    """

    # the CMU Pronouncing Dictionary file that contains the
    # mapping from words to phonetic representations
    dictionary = 'cmu_pronouncing_dictionary/cmudict.0.6'

    # the list of words that we're restricting the
    # suggestions to
    #
    # if empty, this means that it doesn't restrict the list
    # at all (the default), so it'll return any matches at
    # all from the dictionary. could be slow
    wordlist = ''

    # this is the Levenshtein distance threshold, below
    # which a word is considered to be a match
    dist_thresh = 4

    try:
        # arg1 = sys.argv[1:]
        #
        # arg2 = list of single-letter hyphen options (short
        # flags). if succeeded by a colon, then it needs an
        # argument
        #
        # arg3 = full-word double-hyphen options (long
        # flags). if succeeded by an equals sign, then it
        # needs an argument
        #
        # optpairs contains a tuple of option-argument pairs
        #
        # endargs contains the remaining arguments fed in at
        # the end, after all the options have been parsed
        optpairs, endargs = getopt.getopt(
            argv,
            'hvd:t:w:',
            ['help', 'verbose', 'dictionary=', 'thresh=', 'wordlist='])

        for opt,arg in optpairs:
            if opt in ('-h', '--help'):
                usage()
                sys.exit()

            elif opt in ('-d', '--dictionary'):
                dictionary = arg

            elif opt in ('-w', '--wordlist'):
                wordlist = arg

            elif opt in ('-t', '--thresh'):
                try:
                    dist_thresh = int(arg)
                except:
                    print 'Usage error: distance threshold must be a number'
                    sys.exit(2)
                if dist_thresh<2:
                    print 'For some reason, setting the threshold below 2 rarely finds anything. Just warning you.'

            elif opt in ('-v', '--verbose'):
                global verbose
                verbose = True

    except getopt.GetoptError:
        usage()
        sys.exit(2)

    # if the user were to feed in the target words, followed
    # by some arguments, getopt won't notice, so let's just
    # check that none of our putative target words begin
    # with a hyphen
    for endarg in endargs:
        if endarg[0] == '-':
            print 'Usage error: all of your option flags need to come before your target word arguments'
            sys.exit(2)

    matches, nonmatches = begin_search(endargs, dictionary, wordlist, dist_thresh)
    
    if verbose:
        # if we're in verbose mode, also print the nonmatches
        for nonmatch in nonmatches:
            print '\t%s' % nonmatch
    for match in matches:
        print match


    
############################################################
if __name__ == "__main__":

    main(sys.argv[1:])


